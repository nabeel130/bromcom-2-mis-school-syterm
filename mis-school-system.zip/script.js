// Global state
let currentPage = 'dashboard';
let students = [
  { id: 'S001', name: 'Abid' }, { id: 'S002', name: 'Rakeeb' }, { id: 'S003', name: 'Nadeem' },
  { id: 'S004', name: 'Waqas' }, { id: 'S005', name: 'Rais' }, { id: 'S006', name: 'Arfan' },
  { id: 'S007', name: 'Sebi' }, { id: 'S008', name: 'Rehan' }, { id: 'S009', name: 'Adeel' },
  { id: 'S010', name: 'Haffis' }, { id: 'S011', name: 'Ambo' }, { id: 'S012', name: 'Sajad' },
  { id: 'S013', name: 'Afraz' }, { id: 'S014', name: 'Syed' }, { id: 'S015', name: 'Ideeris' },
  { id: 'S016', name: 'Fasil' }, { id: 'S017', name: 'Shazi' }, { id: 'S018', name: 'Nasir' },
  { id: 'S019', name: 'Usman' }, { id: 'S020', name: 'Shaf' }, { id: 'S021', name: 'Tahir' },
  { id: 'S022', name: 'Aqeel' }
];

let attendanceData = {};
let behaviorLog = [];
let paLog = [];
let bellSchedule = [];
let detentions = [];
let emergencyActive = false;

// Audio context for bell and announcements
let audioContext = null;

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
  loadData();
  renderAttendance();
  renderBehaviorSelect();
  renderBellSchedule();
  updateDashboard();
  startBellChecker();
});

// Navigation
function showPage(pageId) {
  document.querySelectorAll('.page').forEach(page => page.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));

  document.getElementById(pageId).classList.add('active');
  event.target.classList.add('active');
  currentPage = pageId;
}

// Data persistence
function saveData() {
  localStorage.setItem('mis_attendance', JSON.stringify(attendanceData));
  localStorage.setItem('mis_behavior', JSON.stringify(behaviorLog));
  localStorage.setItem('mis_pa_log', JSON.stringify(paLog));
  localStorage.setItem('mis_bell_schedule', JSON.stringify(bellSchedule));
  localStorage.setItem('mis_detentions', JSON.stringify(detentions));
  localStorage.setItem('mis_assessments', JSON.stringify(assessments));
}

function loadData() {
  attendanceData = JSON.parse(localStorage.getItem('mis_attendance') || '{}');
  behaviorLog = JSON.parse(localStorage.getItem('mis_behavior') || '[]');
  paLog = JSON.parse(localStorage.getItem('mis_pa_log') || '[]');
  bellSchedule = JSON.parse(localStorage.getItem('mis_bell_schedule') || '[]');
  detentions = JSON.parse(localStorage.getItem('mis_detentions') || '[]');
  assessments = JSON.parse(localStorage.getItem('mis_assessments') || '[]');
}

// Attendance functions
function renderAttendance() {
  const grid = document.getElementById('attendance-grid');
  const today = new Date().toISOString().split('T')[0];

  if (!attendanceData[today]) {
    attendanceData[today] = {};
  }

  grid.innerHTML = students.map(student => {
    const status = attendanceData[today][student.id] || 'unknown';
    return `
      <div class="student-card ${status}" onclick="markAttendance('${student.id}', '${today}')">
        <div style="font-weight: bold;">${student.name}</div>
        <div style="font-size: 12px; margin-top: 5px;">${status.toUpperCase()}</div>
      </div>
    `;
  }).join('');
}

function markAttendance(studentId, date) {
  if (!attendanceData[date]) attendanceData[date] = {};

  const currentStatus = attendanceData[date][studentId] || 'unknown';
  const statuses = ['unknown', 'present', 'late', 'absent'];
  const currentIndex = statuses.indexOf(currentStatus);
  const nextStatus = statuses[(currentIndex + 1) % statuses.length];

  attendanceData[date][studentId] = nextStatus;
  saveData();
  renderAttendance();
  updateDashboard();
}

function saveAttendance() {
  saveData();
  showStatus('Attendance saved successfully!', 'success');
}

function exportAttendance() {
  const today = new Date().toISOString().split('T')[0];
  const data = attendanceData[today] || {};
  const csv = 'Student,Status\n' +
    students.map(s => `${s.name},${data[s.id] || 'unknown'}`).join('\n');

  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `attendance_${today}.csv`;
  a.click();
}

// Behavior functions
function renderBehaviorSelect() {
  const select = document.getElementById('behavior-student');
  select.innerHTML = '<option value="">Select student...</option>' +
    students.map(s => `<option value="${s.id}">${s.name}</option>`).join('');
}

function logBehavior() {
  const studentId = document.getElementById('behavior-student').value;
  const code = document.getElementById('behavior-code').value;
  const description = document.getElementById('behavior-description').value;

  if (!studentId || !code) {
    showStatus('Please select student and incident type', 'error');
    return;
  }

  const student = students.find(s => s.id === studentId);
  const entry = {
    id: Date.now(),
    student: student.name,
    studentId: studentId,
    code: code,
    description: description,
    timestamp: new Date().toISOString()
  };

  behaviorLog.unshift(entry);

  // Auto-add detention for code 5
  if (code === '5') {
    detentions.push({
      id: Date.now(),
      student: student.name,
      studentId: studentId,
      reason: description,
      date: new Date().toISOString().split('T')[0],
      status: 'scheduled'
    });
  }

  saveData();
  renderBehaviorLog();
  renderDetentions();
  updateDashboard();

  // Clear form
  document.getElementById('behavior-student').value = '';
  document.getElementById('behavior-description').value = '';
  showStatus('Behavior incident logged', 'success');
}

function renderBehaviorLog() {
  const log = document.getElementById('behavior-log');
  log.innerHTML = behaviorLog.slice(0, 10).map(entry => `
    <div class="log-entry">
      <strong>${entry.student}</strong> - Code ${entry.code} - ${new Date(entry.timestamp).toLocaleString()}
      ${entry.description ? `<br><small>${entry.description}</small>` : ''}
    </div>
  `).join('');
}

// PA System functions
async function makeAnnouncement() {
  const text = document.getElementById('pa-text').value.trim();
  if (!text) {
    showStatus('Please enter announcement text', 'error');
    return;
  }

  // Initialize audio context if needed
  if (!audioContext) {
    audioContext = new (window.AudioContext || window.webkitAudioContext)();
  }

  const utterance = new SpeechSynthesisUtterance(text);
  utterance.volume = document.getElementById('pa-volume').value / 100;
  utterance.rate = document.getElementById('pa-rate').value;

  speechSynthesis.speak(utterance);

  // Log announcement
  paLog.unshift({
    id: Date.now(),
    text: text,
    timestamp: new Date().toISOString(),
    type: 'announcement'
  });

  saveData();
  renderPALog();
  updateDashboard();

  document.getElementById('pa-text').value = '';
  showStatus('Announcement made', 'success');
}

function triggerLockdown() {
  if (confirm('Activate EVACUATION? This will trigger emergency procedures.')) {
    emergencyActive = true;
    document.getElementById('emergency-alert').style.display = 'block';
    document.getElementById('emergency-message').textContent =
      'EVACUATION ALERT: All students and staff must leave the building immediately using the nearest safe exit. Teachers, take your class roster and lead students to the designated assembly area. Do not re-enter until all-clear is given.';

    // Speak evacuation message
    const utterance = new SpeechSynthesisUtterance(
      'Attention please. This is an evacuation notice. All students and staff must leave the building immediately using the nearest safe exit. Teachers, take your class roster and lead students to the designated assembly area. Do not re-enter the building until the all-clear is given.'
    );
    speechSynthesis.speak(utterance);

    paLog.unshift({
      id: Date.now(),
      text: 'EVACUATION ALERT ACTIVATED',
      timestamp: new Date().toISOString(),
      type: 'emergency'
    });

    saveData();
    renderPALog();
    renderEmergencyLog();
  }
}

function triggerFireAlarm() {
  if (confirm('Activate FIRE ALARM? This will trigger continuous siren.')) {
    emergencyActive = true;
    document.getElementById('emergency-alert').style.display = 'block';
    document.getElementById('emergency-message').textContent =
      'FIRE ALARM ACTIVE: Evacuate immediately! Use nearest safe exit.';

    // Start continuous fire siren
    startFireSiren();

    paLog.unshift({
      id: Date.now(),
      text: 'FIRE ALARM ACTIVATED',
      timestamp: new Date().toISOString(),
      type: 'emergency'
    });

    saveData();
    renderPALog();
    renderEmergencyLog();
  }
}

function allClear() {
  emergencyActive = false;
  document.getElementById('emergency-alert').style.display = 'none';
  stopSiren();

  // Speak all clear message
  const utterance = new SpeechSynthesisUtterance(
    'Attention please. All clear. The emergency has been resolved. Normal activities may resume.'
  );
  speechSynthesis.speak(utterance);

  paLog.unshift({
    id: Date.now(),
    text: 'ALL CLEAR - Emergency resolved',
    timestamp: new Date().toISOString(),
    type: 'emergency'
  });

  saveData();
  renderPALog();
  renderEmergencyLog();
  showStatus('All clear signal sent', 'success');
}

function clearEmergency() {
  allClear();
}

function renderPALog() {
  const log = document.getElementById('pa-log');
  log.innerHTML = paLog.slice(0, 10).map(entry => `
    <div class="log-entry">
      <strong>${entry.type.toUpperCase()}</strong> - ${new Date(entry.timestamp).toLocaleString()}
      <br><small>${entry.text}</small>
    </div>
  `).join('');
}

// Bell functions
function ringBell() {
  if (!audioContext) {
    audioContext = new (window.AudioContext || window.webkitAudioContext)();
  }

  // Prestigious High School Bell with 3 LONG rings
  const volume = document.getElementById('bell-volume').value / 100;
  const timings = [0, 2000, 4500]; // Longer intervals between rings

  timings.forEach((delay, ring) => {
    setTimeout(() => {
      playBellTone(volume);
    }, delay);
  });

  paLog.unshift({
    id: Date.now(),
    text: 'Mosque Bell rang (3 traditional rings)',
    timestamp: new Date().toISOString(),
    type: 'bell'
  });

  saveData();
  renderPALog();
}

function playBellTone(volume) {
  const duration = 6.0; // Extended to 6 seconds for mosque-style adhan character
  const sampleRate = audioContext.sampleRate;
  const buffer = audioContext.createBuffer(1, duration * sampleRate, sampleRate);

  const data = buffer.getChannelData(0);
  // Islamic/Mosque Adhan-style harmonics (traditional Middle Eastern scales)
  const harmonics = [
    { freq: 261.63, amp: 1.0 },   // C4 - fundamental (strong base)
    { freq: 329.63, amp: 0.9 },   // E4 - major third (Islamic scale)
    { freq: 392.00, amp: 0.8 },   // G4 - perfect fifth
    { freq: 523.25, amp: 0.7 },   // C5 - octave
    { freq: 659.25, amp: 0.6 },   // E5 - major sixth
    { freq: 783.99, amp: 0.5 },   // G5 - dominant
    { freq: 1046.5, amp: 0.4 },   // C6 - high octave
    { freq: 1318.5, amp: 0.3 }    // E6 - brilliant high note
  ];

  for(let i = 0; i < duration * sampleRate; i++){
    const t = i / sampleRate;
    let wave = 0;
    // Mosque-style call with more pronounced, echoing strike
    const strike = (t < 0.1) ? Math.random() * 0.6 : 0;

    harmonics.forEach(harm => {
      // Traditional Islamic musical decay - slower and more sustained
      const decayRate = 0.05 + (harmonics.indexOf(harm) * 0.02);
      const envelope = Math.exp(-t * decayRate);
      wave += Math.sin(2 * Math.PI * harm.freq * t) * harm.amp * envelope;
    });

    // Longer attack and very slow decay for mosque adhan resonance
    const attackTime = 0.04;
    const attack = t < attackTime ? (t / attackTime) : 1;
    const overallEnvelope = attack * Math.exp(-t * 0.04); // Very slow decay for spiritual resonance

    data[i] = (wave * 0.5 + strike) * overallEnvelope * volume;
  }

  const source = audioContext.createBufferSource();
  source.buffer = buffer;
  source.connect(audioContext.destination);
  source.start(0);
}

function addBellTime() {
  const time = prompt('Enter bell time (HH:MM):', '09:00');
  if (time) {
    bellSchedule.push({ time: time, active: true });
    saveData();
    renderBellSchedule();
  }
}

function renderBellSchedule() {
  const list = document.getElementById('bell-schedule-list');
  if (bellSchedule.length === 0) {
    list.innerHTML = '<p>No scheduled bells</p>';
    return;
  }

  list.innerHTML = bellSchedule.map((item, index) => `
    <div style="display: flex; justify-content: space-between; align-items: center; padding: 10px; border: 1px solid var(--border); margin: 5px 0; border-radius: 4px;">
      <span>${item.time} ${item.active ? '(Active)' : '(Inactive)'}</span>
      <button class="btn btn-danger" onclick="removeBellTime(${index})">Remove</button>
    </div>
  `).join('');
}

function removeBellTime(index) {
  bellSchedule.splice(index, 1);
  saveData();
  renderBellSchedule();
}

function startBellChecker() {
  setInterval(() => {
    if (bellSchedule.length === 0) return;

    const now = new Date();
    const currentTime = now.getHours().toString().padStart(2, '0') + ':' +
                       now.getMinutes().toString().padStart(2, '0');

    bellSchedule.forEach(schedule => {
      if (schedule.active && schedule.time === currentTime) {
        ringBell();
      }
    });
  }, 60000); // Check every minute
}

// Detentions functions
function renderDetentions() {
  const tbody = document.getElementById('detention-table-body');
  if (detentions.length === 0) {
    tbody.innerHTML = '<tr><td colspan="4" style="text-align: center; color: var(--muted);">No detentions scheduled</td></tr>';
    return;
  }

  tbody.innerHTML = detentions.map(detention => `
    <tr>
      <td>${detention.student}</td>
      <td>${detention.reason}</td>
      <td>${detention.date}</td>
      <td>
        <select onchange="updateDetentionStatus(${detention.id}, this.value)">
          <option value="scheduled" ${detention.status === 'scheduled' ? 'selected' : ''}>Scheduled</option>
          <option value="served" ${detention.status === 'served' ? 'selected' : ''}>Served</option>
          <option value="cancelled" ${detention.status === 'cancelled' ? 'selected' : ''}>Cancelled</option>
        </select>
      </td>
    </tr>
  `).join('');
}

function updateDetentionStatus(id, status) {
  const detention = detentions.find(d => d.id === id);
  if (detention) {
    detention.status = status;
    saveData();
    renderDetentions();
  }
}

// Audio functions for emergency
let sirenSource = null;

function startFireSiren() {
  if (!audioContext) {
    audioContext = new (window.AudioContext || window.webkitAudioContext)();
  }

  stopSiren();

  const oscA = audioContext.createOscillator();
  const oscB = audioContext.createOscillator();
  oscA.type = 'sawtooth';
  oscB.type = 'sine';
  oscA.frequency.value = 900;
  oscB.frequency.value = 1300;

  const lfo = audioCtx.createOscillator();
  lfo.type = 'sine';
  lfo.frequency.value = 0.6;

  const lfoGain = audioContext.createGain();
  lfoGain.gain.value = 300;
  lfo.connect(lfoGain);
  lfoGain.connect(oscA.frequency);
  lfoGain.connect(oscB.frequency);

  const gainNode = audioContext.createGain();
  gainNode.gain.value = 0;
  oscA.connect(gainNode);
  oscB.connect(gainNode);
  gainNode.connect(audioContext.destination);

  gainNode.gain.setValueAtTime(0.0001, audioContext.currentTime);
  gainNode.gain.exponentialRampToValueAtTime(1.0, audioContext.currentTime + 0.5);

  oscA.start(audioContext.currentTime);
  oscB.start(audioContext.currentTime);
  lfo.start(audioContext.currentTime);

  sirenSource = { oscA, oscB, lfo, gainNode };
}

function stopSiren() {
  if (sirenSource) {
    const now = audioContext.currentTime;
    sirenSource.gainNode.gain.setTargetAtTime(0.0001, now, 0.2);
    setTimeout(() => {
      try {
        sirenSource.oscA.stop();
        sirenSource.oscB.stop();
        sirenSource.lfo.stop();
      } catch (e) {}
    }, 500);
    sirenSource = null;
  }
}

// Emergency log functions
function renderEmergencyLog() {
  const log = document.getElementById('emergency-log');
  const emergencyMessages = paLog.filter(entry => entry.type === 'emergency');

  if (emergencyMessages.length === 0) {
    log.innerHTML = '<p style="color: var(--muted); text-align: center;">No emergency messages sent yet</p>';
    return;
  }

  log.innerHTML = emergencyMessages.slice(0, 20).map(entry => `
    <div class="log-entry" style="border-left: 4px solid var(--danger); padding-left: 10px; margin: 5px 0;">
      <strong style="color: var(--danger);">${entry.text}</strong>
      <br><small style="color: var(--muted);">${new Date(entry.timestamp).toLocaleString()}</small>
    </div>
  `).join('');
}

function clearEmergencyLog() {
  if (confirm('Clear all emergency message history?')) {
    // Remove only emergency messages from paLog
    const nonEmergencyMessages = paLog.filter(entry => entry.type !== 'emergency');
    paLog.length = 0; // Clear the array
    paLog.push(...nonEmergencyMessages); // Add back non-emergency messages
    saveData();
    renderEmergencyLog();
    renderPALog(); // Update PA log as well
    showStatus('Emergency log cleared', 'success');
  }
}

// Dashboard functions
function updateDashboard() {
  // Attendance summary
  const today = new Date().toISOString().split('T')[0];
  const todayData = attendanceData[today] || {};
  const present = Object.values(todayData).filter(status => status === 'present').length;
  const absent = Object.values(todayData).filter(status => status === 'absent').length;
  const late = Object.values(todayData).filter(status => status === 'late').length;

  document.getElementById('attendance-summary').innerHTML = `
    <div style="display: flex; justify-content: space-around; margin-top: 10px;">
      <div style="text-align: center;">
        <div style="font-size: 24px; color: var(--success);">${present}</div>
        <div>Present</div>
      </div>
      <div style="text-align: center;">
        <div style="font-size: 24px; color: var(--danger);">${absent}</div>
        <div>Absent</div>
      </div>
      <div style="text-align: center;">
        <div style="font-size: 24px; color: var(--warning);">${late}</div>
        <div>Late</div>
      </div>
    </div>
  `;

  // Behavior summary
  const todayIncidents = behaviorLog.filter(entry =>
    entry.timestamp.startsWith(today)
  ).length;

  document.getElementById('behavior-summary').innerHTML = `
    <div style="font-size: 24px; color: var(--warning); margin: 10px 0;">${todayIncidents}</div>
    <div>Incidents today</div>
  `;

  // Recent announcements
  const recentPA = paLog.slice(0, 3);
  document.getElementById('announcement-log').innerHTML = recentPA.length ?
    recentPA.map(entry => `<div style="margin: 5px 0; padding: 5px; background: #f0f0f0; border-radius: 3px;">${entry.text}</div>`).join('') :
    'No recent announcements';

  // Next bell
  const nextBell = bellSchedule.find(schedule => schedule.active);
  document.getElementById('bell-schedule').innerHTML = nextBell ?
    `Next scheduled: ${nextBell.time}` :
    'No scheduled bells';
}

// Assessment functions
let assessments = [];

function openAssessmentModal() {
  const subject = document.getElementById('assessment-subject').value;
  const type = document.getElementById('assessment-type').value;

  if (!subject || !type) {
    showStatus('Please select subject and assessment type', 'error');
    return;
  }

  // Simple assessment recording (in real Bromcom this would be more complex)
  const assessment = {
    id: Date.now(),
    subject: subject,
    type: type,
    date: new Date().toISOString().split('T')[0],
    timestamp: new Date().toISOString()
  };

  assessments.unshift(assessment);
  saveData();
  renderAssessmentLog();
  showStatus('Assessment recorded', 'success');
}

function renderAssessmentLog() {
  const log = document.getElementById('assessment-log');
  if (assessments.length === 0) {
    log.innerHTML = 'No assessments recorded yet';
    return;
  }

  log.innerHTML = assessments.slice(0, 10).map(assessment => `
    <div class="log-entry">
      <strong>${assessment.subject.toUpperCase()}</strong> - ${assessment.type}
      <br><small>${new Date(assessment.timestamp).toLocaleString()}</small>
    </div>
  `).join('');
}

// Reporting functions
function generateReport() {
  const reportType = document.getElementById('report-type').value;
  const period = document.getElementById('report-period').value;
  const results = document.getElementById('report-results');

  let reportData = '';

  switch(reportType) {
    case 'attendance':
      const today = new Date().toISOString().split('T')[0];
      const todayData = attendanceData[today] || {};
      const present = Object.values(todayData).filter(status => status === 'present').length;
      const absent = Object.values(todayData).filter(status => status === 'absent').length;
      const late = Object.values(todayData).filter(status => status === 'late').length;

      reportData = `
        <h4>Attendance Report - ${period === 'today' ? 'Today' : 'Period'}</h4>
        <div style="display: flex; gap: 20px; margin: 20px 0;">
          <div style="text-align: center; padding: 15px; background: var(--success); color: white; border-radius: 8px;">
            <div style="font-size: 24px; font-weight: bold;">${present}</div>
            <div>Present</div>
          </div>
          <div style="text-align: center; padding: 15px; background: var(--danger); color: white; border-radius: 8px;">
            <div style="font-size: 24px; font-weight: bold;">${absent}</div>
            <div>Absent</div>
          </div>
          <div style="text-align: center; padding: 15px; background: var(--warning); color: white; border-radius: 8px;">
            <div style="font-size: 24px; font-weight: bold;">${late}</div>
            <div>Late</div>
          </div>
        </div>
      `;
      break;

    case 'behavior':
      const todayIncidents = behaviorLog.filter(entry =>
        entry.timestamp.startsWith(new Date().toISOString().split('T')[0])
      ).length;

      reportData = `
        <h4>Behavior Report - ${period === 'today' ? 'Today' : 'Period'}</h4>
        <div style="padding: 20px; background: var(--warning); color: white; border-radius: 8px; margin: 20px 0;">
          <div style="font-size: 24px; font-weight: bold;">${todayIncidents}</div>
          <div>Behavior Incidents</div>
        </div>
        <div style="margin-top: 15px;">
          <strong>Recent Incidents:</strong>
          <ul>
            ${behaviorLog.slice(0, 5).map(entry => `<li>${entry.student} - Code ${entry.code}</li>`).join('')}
          </ul>
        </div>
      `;
      break;

    case 'assessments':
      reportData = `
        <h4>Assessment Report - ${period === 'today' ? 'Today' : 'Period'}</h4>
        <div style="padding: 20px; background: var(--primary); color: white; border-radius: 8px; margin: 20px 0;">
          <div style="font-size: 24px; font-weight: bold;">${assessments.length}</div>
          <div>Assessments Recorded</div>
        </div>
        <div style="margin-top: 15px;">
          <strong>Recent Assessments:</strong>
          <ul>
            ${assessments.slice(0, 5).map(assessment => `<li>${assessment.subject} - ${assessment.type}</li>`).join('')}
          </ul>
        </div>
      `;
      break;

    case 'detentions':
      reportData = `
        <h4>Detention Report - ${period === 'today' ? 'Today' : 'Period'}</h4>
        <div style="padding: 20px; background: var(--danger); color: white; border-radius: 8px; margin: 20px 0;">
          <div style="font-size: 24px; font-weight: bold;">${detentions.length}</div>
          <div>Detentions Scheduled</div>
        </div>
        <div style="margin-top: 15px;">
          <strong>Scheduled Detentions:</strong>
          <ul>
            ${detentions.slice(0, 5).map(detention => `<li>${detention.student} - ${detention.reason}</li>`).join('')}
          </ul>
        </div>
      `;
      break;
  }

  results.innerHTML = reportData;
}

function exportReport() {
  const reportType = document.getElementById('report-type').value;
  const period = document.getElementById('report-period').value;

  let csvContent = '';
  let filename = '';

  switch(reportType) {
    case 'attendance':
      const today = new Date().toISOString().split('T')[0];
      const todayData = attendanceData[today] || {};
      csvContent = 'Student,Status\n' +
        students.map(s => `${s.name},${todayData[s.id] || 'unknown'}`).join('\n');
      filename = `attendance_report_${today}.csv`;
      break;

    case 'behavior':
      csvContent = 'Student,Code,Description,Date\n' +
        behaviorLog.map(entry => `"${entry.student}","${entry.code}","${entry.description}","${new Date(entry.timestamp).toLocaleDateString()}"`).join('\n');
      filename = `behavior_report_${period}.csv`;
      break;

    case 'assessments':
      csvContent = 'Subject,Type,Date\n' +
        assessments.map(assessment => `"${assessment.subject}","${assessment.type}","${assessment.date}"`).join('\n');
      filename = `assessment_report_${period}.csv`;
      break;

    case 'detentions':
      csvContent = 'Student,Reason,Date,Status\n' +
        detentions.map(detention => `"${detention.student}","${detention.reason}","${detention.date}","${detention.status}"`).join('\n');
      filename = `detention_report_${period}.csv`;
      break;
  }

  if (csvContent) {
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    showStatus('Report exported successfully', 'success');
  } else {
    showStatus('No data to export', 'error');
  }
}

// Utility functions
function showStatus(message, type) {
  const status = document.createElement('div');
  status.className = `status ${type}`;
  status.textContent = message;
  status.style.position = 'fixed';
  status.style.top = '20px';
  status.style.right = '20px';
  status.style.zIndex = '1000';

  document.body.appendChild(status);
  setTimeout(() => {
    document.body.removeChild(status);
  }, 3000);
}

// Initialize everything
renderBehaviorLog();
renderPALog();
renderEmergencyLog();
renderAssessmentLog();
renderDetentions();